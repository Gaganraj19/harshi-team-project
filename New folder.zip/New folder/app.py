import os
import cv2
import sys
import random
import string
import smtplib
import pandas as pd
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from flask import Flask, request, render_template_string, session, jsonify, Response

# Initialize Flask app
app = Flask(__name__)
app.secret_key = 'replace_this_with_a_strong_secret_key'

# Email sending function
def send_email(to_email, subject, body):
    smtp_server = 'smtp.gmail.com'
    smtp_port = 587
    from_email = 'gaganraj774@gmail.com'  # Replace with your Gmail address
    password = 'htfy pszl nmif hsgk'       # Replace with your Gmail app password

    msg = MIMEMultipart()
    msg['From'] = from_email
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    try:
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(from_email, password)
        server.sendmail(from_email, to_email, msg.as_string())
        print(f'Email successfully sent to {to_email}')
    except Exception as e:
        print(f'Failed to send email: {e}')
        raise
    finally:
        server.quit()

# OTP and CAPTCHA generation functions
def generate_otp(length=6):
    return ''.join(random.choices(string.digits, k=length))

def generate_captcha(length=6):
    chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789'
    return ''.join(random.choices(chars, k=length))

# Camera setup
output_dir = "captured_faces"
os.makedirs(output_dir, exist_ok=True)
registered_faces_dir = "registered_faces"
os.makedirs(registered_faces_dir, exist_ok=True)

face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
cap = cv2.VideoCapture(0)

# Utility: load registered face images and compute their encodings for face comparison
def is_face_matching(test_img_path, registered_img_path, threshold=0.6):
    try:
        test_img = cv2.imread(test_img_path, cv2.IMREAD_GRAYSCALE)
        reg_img = cv2.imread(registered_img_path, cv2.IMREAD_GRAYSCALE)
        if test_img is None or reg_img is None:
            return False
        test_img = cv2.resize(test_img, (200, 200))
        reg_img = cv2.resize(reg_img, (200, 200))
        res = cv2.matchTemplate(test_img, reg_img, cv2.TM_CCOEFF_NORMED)
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
        return max_val >= threshold
    except Exception as e:
        print(f"Face matching error: {e}")
        return False

REGISTRATION_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Register</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6;
            margin: 0; padding: 0;
            min-height: 100vh;
            display: flex; flex-direction: column; align-items: center;
            color: #333;
        }
        .container {
            background: white;
            max-width: 400px; width: 90%;
            padding: 30px 35px;
            border-radius: 10px;
            box-shadow: 0 15px 25px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        h1 {
            color: #4CAF50; margin-bottom: 20px; font-weight: 700; text-align: center;
        }
        label { display: block; margin-bottom: 6px; font-weight: 600; }
        input[type="text"], input[type="email"], input[type="tel"], input[type="password"] {
            width: 100%; padding: 10px 12px; margin-bottom: 15px;
            border: 1px solid #ccc; border-radius: 6px;
            box-sizing: border-box; font-size: 16px; transition: border-color 0.3s ease;
        }
        input:focus { border-color: #4CAF50; outline: none; }

        .captcha-box {
            display: flex; align-items: center; margin-bottom: 15px;
        }
        .captcha-code {
            background: #ddd; font-weight: 700; font-size: 20px;
            padding: 10px 15px; border-radius: 6px; user-select: none;
            letter-spacing: 3px; margin-right: 15px; font-family: monospace;
        }
        .button, button {
            background-color: #4caf50; color: white; padding: 12px 20px;
            border: none; border-radius: 6px; font-weight: 600;
            cursor: pointer; text-align: center; transition: background-color 0.3s ease;
            width: 100%; font-size: 16px;
        }
        .button:hover, button:hover { background-color: #3b8f3b; }
        .small-button {
            width: auto; padding: 10px 15px; font-size: 14px;
            margin-top: -10px; margin-bottom: 15px; display: inline-block;
            margin-right: 10px;
        }
        .error { color: #d93025; font-weight: 600; margin-bottom: 10px; }

        /* Camera Section */
        #video-container {
            max-width: 350px; margin: 0 auto 20px auto;
            border: 3px solid #4CAF50; border-radius: 8px;
            overflow: hidden;
        }
        img#video-feed { width: 100%; }
        #capture-button {
            background-color: #4CAF50; color: white; font-size: 18px;
            padding: 10px 20px; border: none; border-radius: 6px;
            cursor: pointer; margin-bottom: 30px; user-select: none; width: 100%;
        }
        #capture-button:hover { background-color: #45a049; }
        #message {
            font-size: 1rem; color: #4caf50; margin-bottom: 15px; min-height: 1.2rem;
            text-align: center;
        }
        @media (max-width: 480px) {
            .container { padding: 20px 25px; }
            h1 { font-size: 24px; }
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Register</h1>
    {% if message %}
      <div class="message">{{ message }}</div>
    {% endif %}
    {% if error %}
      <div class="error">{{ error }}</div>
    {% endif %}
    <form id="registrationForm" method="POST" action="/register" novalidate>
        <label for="name">Name</label>
        <input type="text" id="name" name="name" required />
        
        <label for="uid">UID</label>
        <input type="text" id="uid" name="uid" required />
        
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required />
        
        <label for="phone">Phone</label>
        <input type="tel" id="phone" name="phone" pattern="\\d{10,15}" required placeholder="10-15 digits" />
        
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required minlength="8" placeholder="At least 8 characters" />
        
        <label for="confirm_password">Confirm Password</label>
        <input type="password" id="confirm_password" name="confirm_password" required minlength="8" placeholder="Re-enter your password" />
        
        <button type="button" id="sendOtpBtn" class="small-button">Send OTP</button>
        <button type="button" id="resendOtpBtn" class="small-button" style="display:none;">Resend OTP</button>
        <div id="otpInfo" style="margin-bottom:10px; color: #4caf50; font-weight: 600;"></div>

        <label for="otp">Enter OTP</label>
        <input type="text" id="otp" name="otp" pattern="\\d{6}" required placeholder="6 digit OTP" />
        
        <label for="captcha">CAPTCHA</label>
        <div class="captcha-box">
            <div class="captcha-code" id="captchaCode">{{captcha}}</div>
            <button type="button" id="refreshCaptcha" title="Refresh CAPTCHA">&#x21bb;</button>
        </div>
        <input type="text" id="captcha" name="captcha" required maxlength="6" placeholder="Enter CAPTCHA" />
        
        <div class="error" id="errorMessage"></div>
        <button type="submit" class="button">Register</button>
    </form>
</div>

<!-- Camera section for capturing face -->
<div class="container">
    <h1>Capture Your Face</h1>
    <p>Please click "Capture Frame" to take your face photo for registration.</p>
    <div id="video-container">
        <img id="video-feed" src="{{ url_for('video_feed') }}" alt="Live Camera Feed" />
    </div>
    <button id="capture-button">Capture Frame</button><br/>
    <div id="message"></div>
</div>

<script>
function sendOtp(email) {
    return fetch('/send_otp', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({email: email})
    });
}

document.getElementById('sendOtpBtn').addEventListener('click', function() {
    var email = document.getElementById('email').value.trim();
    if(!email) {
        alert('Please enter your email before requesting OTP.');
        return;
    }
    sendOtp(email)
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            document.getElementById('otpInfo').textContent = 'OTP sent to ' + email;
            document.getElementById('sendOtpBtn').style.display = 'none';
            document.getElementById('resendOtpBtn').style.display = 'inline-block';
        } else {
            document.getElementById('otpInfo').textContent = 'Failed to send OTP: ' + data.error;
        }
    })
    .catch(() => {
        document.getElementById('otpInfo').textContent = 'Error sending OTP.';
    });
});

document.getElementById('resendOtpBtn').addEventListener('click', function() {
    var email = document.getElementById('email').value.trim();
    if(!email) {
        alert('Please enter your email before resending OTP.');
        return;
    }
    sendOtp(email)
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            document.getElementById('otpInfo').textContent = 'OTP resent to ' + email;
        } else {
            document.getElementById('otpInfo').textContent = 'Failed to resend OTP: ' + data.error;
        }
    })
    .catch(() => {
        document.getElementById('otpInfo').textContent = 'Error resending OTP.';
    });
});

document.getElementById('refreshCaptcha').addEventListener('click', function() {
    fetch('/refresh_captcha')
    .then(response => response.json())
    .then(data => {
        document.getElementById('captchaCode').textContent = data.captcha;
    });
});

document.getElementById('registrationForm').addEventListener('submit', function(e) {
    var otp = document.getElementById('otp').value.trim();
    var captchaInput = document.getElementById('captcha').value.trim();
    var captchaCode = document.getElementById('captchaCode').textContent.trim();
    var password = document.getElementById('password').value;
    var confirmPassword = document.getElementById('confirm_password').value;
    var errorMessage = '';

    if (!password) {
        errorMessage = 'Please enter a password.';
    } else if (password.length < 8) {
        errorMessage = 'Password must be at least 8 characters.';
    } else if (password !== confirmPassword) {
        errorMessage = 'Passwords do not match.';
    } else if(!otp.match(/^\\d{6}$/)) {
        errorMessage = 'Please enter a valid 6-digit OTP.';
    } else if(captchaInput.length !== 6) {
        errorMessage = 'Please enter the 6-character CAPTCHA.';
    } else if(captchaInput !== captchaCode) {
        errorMessage = 'CAPTCHA does not match.';
    }

    if(errorMessage) {
        e.preventDefault();
        document.getElementById('errorMessage').textContent = errorMessage;
    }
});

// Camera capture button functionality
const captureBtn = document.getElementById('capture-button');
const messageDiv = document.getElementById('message');

captureBtn.addEventListener('click', () => {
    messageDiv.textContent = "Capturing...";
    fetch('/save_frame_register')
        .then(response => {
            if (response.ok) {
                messageDiv.style.color = "#4caf50";
                messageDiv.textContent = "Face captured!";
            } else {
                response.text().then(text => {
                    messageDiv.style.color = "#e53935";
                    messageDiv.textContent = text;
                });
            }
        }).catch(() => {
            messageDiv.style.color = "#e53935";
            messageDiv.textContent = "Error capturing face.";
        });
});
</script>
</body>
</html>
"""

LOGIN_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Login</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6;
            margin: 0; padding: 0;
            min-height: 100vh;
            display: flex; flex-direction: column; align-items: center;
            color: #333;
        }
        .container {
            background: white;
            max-width: 400px; width: 90%;
            padding: 30px 35px;
            border-radius: 10px;
            box-shadow: 0 15px 25px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        h1 {
            color: #4CAF50; margin-bottom: 20px; font-weight: 700; text-align: center;
        }
        label { display: block; margin-bottom: 6px; font-weight: 600; }
        input[type="text"], input[type="password"] {
            width: 100%; padding: 10px 12px; margin-bottom: 15px;
            border: 1px solid #ccc; border-radius: 6px;
            box-sizing: border-box; font-size: 16px; transition: border-color 0.3s ease;
        }
        input:focus { border-color: #4CAF50; outline: none; }

        .button, button {
            background-color: #4caf50; color: white; padding: 12px 20px;
            border: none; border-radius: 6px; font-weight: 600;
            cursor: pointer; text-align: center; transition: background-color 0.3s ease;
            width: 100%; font-size: 16px;
        }
        .button:hover, button:hover { background-color: #3b8f3b; }

        /* Camera Section */
        #video-container {
            max-width: 350px; margin: 0 auto 20px auto;
            border: 3px solid #4CAF50; border-radius: 8px;
            overflow: hidden;
        }
        img#video-feed { width: 100%; }
        #capture-button {
            background-color: #4CAF50; color: white; font-size: 18px;
            padding: 10px 20px; border: none; border-radius: 6px;
            cursor: pointer; margin-bottom: 30px; user-select: none; width: 100%;
        }
        #capture-button:hover { background-color: #45a049; }
        #message {
            font-size: 1rem; color: #e53935; margin-bottom: 15px; min-height: 1.2rem;
            text-align: center;
        }
        .error {
            color: #d93025; font-weight: 600; margin-bottom: 15px; text-align: center;
        }
        @media (max-width: 480px) {
            .container { padding: 20px 25px; }
            h1 { font-size: 24px; }
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Login</h1>
    <form id="loginForm" method="POST" action="/login" novalidate>
        <label for="name">Name</label>
        <input type="text" id="name" name="name" required />
        
        <label for="uid">UID</label>
        <input type="text" id="uid" name="uid" required />
        
        <div id="errorMessage" class="error"></div>
        <button type="submit" class="button">Login</button>
    </form>
</div>

<div class="container">
    <h1>Face Confirmation</h1>
    <p>Please show your face to camera and click "Capture Frame" to verify identity.</p>
    <div id="video-container">
        <img id="video-feed" src="{{ url_for('video_feed') }}" alt="Live Camera Feed" />
    </div>
    <button id="capture-button">Capture Frame</button><br/>
    <div id="message"></div>
</div>

<script>
const loginForm = document.getElementById('loginForm');
const errorMessageDiv = document.getElementById('errorMessage');

loginForm.addEventListener('submit', function(e) {
    e.preventDefault();
    errorMessageDiv.textContent = '';

    const name = document.getElementById('name').value.trim();
    const uid = document.getElementById('uid').value.trim();

    if (!name || !uid) {
        errorMessageDiv.textContent = 'Please enter both Name and UID.';
        return;
    }

    // Store name and uid in sessionStorage to use during face confirmation
    sessionStorage.setItem('login_name', name);
    sessionStorage.setItem('login_uid', uid);

    alert('Please now capture your face using camera and click Capture Frame to verify.');
});

// Capture button for camera feature in login
const captureBtn = document.getElementById('capture-button');
const messageDiv = document.getElementById('message');

captureBtn.addEventListener('click', () => {
    messageDiv.textContent = "Capturing...";
    fetch('/save_frame_login')
        .then(response => {
            if (response.ok) {
                messageDiv.style.color = "#4caf50";
                messageDiv.textContent = "Face captured! Verifying...";
                // After capture is saved, send AJAX for verification
                verifyFace();
            } else {
                response.text().then(text => {
                    messageDiv.style.color = "#e53935";
                    messageDiv.textContent = text;
                });
            }
        }).catch(() => {
            messageDiv.style.color = "#e53935";
            messageDiv.textContent = "Error capturing face.";
        });
});

function verifyFace() {
    const name = sessionStorage.getItem('login_name');
    const uid = sessionStorage.getItem('login_uid');

    if (!name || !uid) {
        messageDiv.style.color = "#e53935";
        messageDiv.textContent = "Please enter Name and UID in login form first.";
        return;
    }

    fetch('/verify_face', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({name: name, uid: uid})
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            messageDiv.style.color = "#4caf50";
            messageDiv.textContent = "Face verified! Login successful.";
            // Redirect or further actions can be done here
        } else {
            messageDiv.style.color = "#e53935";
            messageDiv.textContent = "Face verification failed: " + data.message;
        }
    })
    .catch(() => {
        messageDiv.style.color = "#e53935";
        messageDiv.textContent = "Error during face verification.";
    });
}
</script>
</body>
</html>
"""

@app.route('/')
def registration_form():
    captcha_code = generate_captcha()
    session['captcha'] = captcha_code
    return render_template_string(REGISTRATION_HTML, captcha=captcha_code)

@app.route('/login_page')
def login_page():
    return render_template_string(LOGIN_HTML)

@app.route('/send_otp', methods=['POST'])
def send_otp():
    data = request.get_json()
    email = data.get('email')
    if not email:
        return jsonify({'success': False, 'error': 'Email is required'}), 400
    try:
        otp_code = generate_otp()
        session['otp'] = otp_code
        subject = "Your OTP Code"
        body = f"Your OTP code is: {otp_code}"
        send_email(email, subject, body)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/refresh_captcha')
def refresh_captcha():
    new_captcha = generate_captcha()
    session['captcha'] = new_captcha
    return jsonify({'captcha': new_captcha})

@app.route('/register', methods=['POST'])
def register():
    name = request.form.get('name', '').strip()
    uid = request.form.get('uid', '').strip()
    email = request.form.get('email', '').strip()
    phone = request.form.get('phone', '').strip()
    password = request.form.get('password', '')
    confirm_password = request.form.get('confirm_password', '')
    user_otp = request.form.get('otp', '').strip()
    user_captcha = request.form.get('captcha', '').strip()
    
    if not all([name, uid, email, phone, password, confirm_password, user_otp, user_captcha]):
        return render_template_string(REGISTRATION_HTML, captcha=session.get('captcha', ''), error="All fields including password, confirm password, OTP, and CAPTCHA are required.")
    
    if len(password) < 8:
        return render_template_string(REGISTRATION_HTML, captcha=session.get('captcha', ''), error="Password must be at least 8 characters.")
    
    if password != confirm_password:
        return render_template_string(REGISTRATION_HTML, captcha=session.get('captcha', ''), error="Password and Confirm Password do not match.")
    
    if user_otp != session.get('otp', ''):
        return render_template_string(REGISTRATION_HTML, captcha=session.get('captcha', ''), error="Invalid OTP. Please try again.")
    
    if user_captcha != session.get('captcha', ''):
        return render_template_string(REGISTRATION_HTML, captcha=session.get('captcha', ''), error="Invalid CAPTCHA. Please try again.")
    
    # Check if a captured frame exists
    saved_frames = [f for f in os.listdir(output_dir) if f.startswith("frame_")]
    if not saved_frames:
        return render_template_string(REGISTRATION_HTML, captcha=session.get('captcha', ''), error="Please capture your face frame before registering.")
    
    # Use only one frame (the first one) for registering
    src = os.path.join(output_dir, saved_frames[0])
    dst = os.path.join(registered_faces_dir, f"{uid}.jpg")
    os.replace(src, dst)

    # Remove any other frames to clear storage
    for f in saved_frames[1:]:
        os.remove(os.path.join(output_dir, f))
        
    # Save registration data to Excel file
    data = {
        'Name': [name],
        'UID': [uid],
        'Email': [email],
        'Phone': [phone],
        'Password': [password]  # Warning: storing passwords as plain text is insecure! For demo only.
    }
    df = pd.DataFrame(data)
    file_path = 'registration_data.xlsx'

    try:
        if os.path.exists(file_path):
            with pd.ExcelWriter(file_path, mode='a', engine='openpyxl', if_sheet_exists='overlay') as writer:
                workbook = writer.book
                if 'Registrations' in workbook.sheetnames:
                    sheet = workbook['Registrations']
                    startrow = sheet.max_row
                else:
                    startrow = 0
                df.to_excel(writer, sheet_name='Registrations', index=False, header=False, startrow=startrow)
        else:
            with pd.ExcelWriter(file_path, mode='w', engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name='Registrations', index=False)
    except Exception as e:
        return render_template_string(REGISTRATION_HTML, captcha=session.get('captcha', ''), error=f"Failed to save registration data: {str(e)}")

    try:
        subject = 'Registration Successful'
        body = f'Thank you for registering, {name}! Your account has been successfully created.'
        send_email(email, subject, body)
    except Exception as e:
        return render_template_string(REGISTRATION_HTML, captcha=session.get('captcha', ''), error=f"Failed to send confirmation email: {str(e)}")
    
    session.pop('otp', None)
    session.pop('captcha', None)

    thank_you_html = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Registration Successful</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6;
            margin: 0; padding: 0;
            height: 100vh;
            display: flex; justify-content: center; align-items: center;
            color: #333;
        }}
        .container {{
            background: white;
            max-width: 420px; width: 90%;
            padding: 30px 35px;
            border-radius: 10px;
            box-shadow: 0 15px 25px rgba(0,0,0,0.1);
            text-align: center;
        }}
        h1 {{
            color: #4CAF50;
            margin-bottom: 20px;
            font-weight: 700;
        }}
        p {{
            font-size: 18px;
            line-height: 1.5;
            margin-bottom: 25px;
            color: #555;
        }}
        .button {{
            display: inline-block;
            padding: 12px 25px;
            background-color: #4caf50;
            color: white;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }}
        .button:hover {{
            background-color: #3b8f3b;
        }}
        @media (max-width: 480px) {{
            .container {{
                padding: 20px 25px;
            }}
            p {{
                font-size: 16px;
            }}
        }}
    </style>
    </head>
    <body>
        <div class="container">
            <h1>Registration Successful!</h1>
            <p>Thank you for registering, <span class="name">{name}</span>!</p>
            <p>A confirmation email has been sent to <span class="email">{email}</span>.</p>
            <a href="/login_page" class="button" aria-label="Go to login page">Go to Login</a>
        </div>
    </body>
    </html>
    """
    return render_template_string(thank_you_html)

# Video feed generator for camera streaming
def gen_frames():
    global cap
    try:
        while True:
            success, frame = cap.read()
            if not success:
                break

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

            ret, buffer = cv2.imencode('.jpg', frame)
            frame_bytes = buffer.tobytes()

            yield (b'--frame\r\n'
                b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
    except GeneratorExit:
        if cap.isOpened():
            cap.release()
    except Exception:
        if cap.isOpened():
            cap.release()
        raise

@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

# Save captured frame during registration (only one frame)
@app.route('/save_frame_register')
def save_frame_register():
    if not cap.isOpened():
        return "Camera is not available", 500

    ret, frame = cap.read()
    if not ret:
        return "Failed to capture frame", 500

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
    if len(faces) == 0:
        return "No face detected", 400

    # Clear existing frames first
    for f in os.listdir(output_dir):
        if f.startswith("frame_"):
            os.remove(os.path.join(output_dir, f))

    cv2.imwrite(os.path.join(output_dir, "frame_0.jpg"), frame)
    return "Frame saved", 200

# Save captured frame during login for verification
login_capture_path = "login_capture.jpg"

@app.route('/save_frame_login')
def save_frame_login():
    if not cap.isOpened():
        return "Camera is not available", 500

    ret, frame = cap.read()
    if not ret:
        return "Failed to capture frame", 500

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
    if len(faces) == 0:
        return "No face detected", 400

    cv2.imwrite(login_capture_path, frame)
    return "Face captured", 200

# Verify face function: compares login captured face with registered face image of given user (name and uid)
@app.route('/verify_face', methods=['POST'])
def verify_face():
    data = request.get_json()
    name = data.get('name', '').strip()
    uid = data.get('uid', '').strip()

    if not name or not uid:
        return jsonify({'success': False, 'message': 'Name and UID are required'}), 400

    if not os.path.exists(login_capture_path):
        return jsonify({'success': False, 'message': 'No face captured for verification'}), 400

    reg_face_path = os.path.join(registered_faces_dir, f"{uid}.jpg")
    if not os.path.exists(reg_face_path):
        return jsonify({'success': False, 'message': 'No registered face data found for this user'}), 404

    if is_face_matching(login_capture_path, reg_face_path):
        return jsonify({'success': True, 'message': 'Face verified successfully'})

    return jsonify({'success': False, 'message': 'Face verification failed'})

@app.route('/shutdown', methods=['POST', 'GET'])
def shutdown():
    global cap
    if cap.isOpened():
        cap.release()
    return '', 204

if __name__ == "__main__":
    try:
        app.run(debug=True)
    finally:
        if cap.isOpened():
            cap.release()
        cv2.destroyAllWindows()
        sys.exit(0)

